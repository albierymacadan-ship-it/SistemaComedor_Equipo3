package Modelo; 

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MonederoTest {

    @Test
    public void testSaldoInicial() {
        Usuario user = new Usuario();
      
        assertEquals(0.0f, user.getMonedero(), "El saldo inicial debería ser 0");
    }

    @Test
    public void testCargarSaldo() {
        Usuario user = new Usuario();
        float montoASumar = 50.0f;
        
       
        user.setMonedero(user.getMonedero() + montoASumar);
        
        assertEquals(50.0f, user.getMonedero(), "El saldo no se actualizó correctamente");
    }

    @Test
    public void testSaldoAcumulado() {
        Usuario user = new Usuario();
        user.setMonedero(10.0f);
        
       
        user.setMonedero(user.getMonedero() + 25.5f);
        
        assertEquals(35.5f, user.getMonedero(), 0.001, "La acumulación de saldo falló");
    }
}
