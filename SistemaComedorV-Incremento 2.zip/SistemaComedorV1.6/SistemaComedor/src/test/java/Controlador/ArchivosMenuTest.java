package Controlador;

import Modelo.Menu;
import Modelo.Plato;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ArchivosMenuTest {

    @Test
    public void testLeerMenu_ListaVacia() {
        Menu menu = new Menu();
        ArrayList<Plato> lista = new ArrayList<>();
        
        
        ArchivosMenu.leerMenu(menu, lista);
        
        assertNotNull(lista, "La lista de platos no debería ser nula");
    }
}